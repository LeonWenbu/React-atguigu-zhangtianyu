import React, { Component } from 'react'

export default class Home extends Component {
	render() {
		return (
			<h2>我是Home组件</h2>
		)
	}
}
