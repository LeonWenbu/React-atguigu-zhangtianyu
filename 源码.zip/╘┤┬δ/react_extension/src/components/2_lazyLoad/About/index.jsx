import React, { Component } from 'react'

export default class About extends Component {
	render() {
		return (
			<h2>我是About组件</h2>
		)
	}
}
